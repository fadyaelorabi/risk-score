const ENGINE_WEIGHTS = Object.freeze({
  vulnerability: 0.45,
  ml: 0.2,
  maintainer: 0.2,
  typosquat: 0.15,
});

// Signals below this value are treated as low-intensity noise and do not
// participate in adaptive package-risk weighting.
const ACTIVE_SIGNAL_THRESHOLD = 20;

// A score must be strictly greater than this threshold to trigger an override.
const CRITICAL_ENGINE_THRESHOLD = 70;

const CRITICAL_ENGINE_THRESHOLDS = Object.freeze({
  vulnerability: CRITICAL_ENGINE_THRESHOLD,
  ml: CRITICAL_ENGINE_THRESHOLD,
  maintainer: CRITICAL_ENGINE_THRESHOLD,
  typosquat: CRITICAL_ENGINE_THRESHOLD,
});

// A single critical engine signal should not be diluted by other engines.
// Order is intentional and defines which reason is reported when several
// components exceed the threshold at the same time.
const RISK_SCORE_OVERRIDES = Object.freeze([
  {
    component: 'typosquat',
    scoreName: 'typosquattingScore',
    label: 'Typosquatting score',
    threshold: CRITICAL_ENGINE_THRESHOLDS.typosquat,
  },
  {
    component: 'ml',
    scoreName: 'mlScore',
    label: 'ML anomaly score',
    threshold: CRITICAL_ENGINE_THRESHOLDS.ml,
  },
  {
    component: 'maintainer',
    scoreName: 'maintainerScore',
    label: 'Maintainer risk score',
    threshold: CRITICAL_ENGINE_THRESHOLDS.maintainer,
  },
  {
    component: 'vulnerability',
    scoreName: 'cvssScore',
    label: 'Vulnerability score',
    threshold: CRITICAL_ENGINE_THRESHOLDS.vulnerability,
  },
]);

const ADAPTIVE_SCORING_REASON =
  'Adaptive weighted scoring: no hard override triggered; only signals at or above the activation threshold contributed.';

// Backward-compatible alias for callers that still import the old name.
const WEIGHTED_SCORING_REASON = ADAPTIVE_SCORING_REASON;

const ENGINE_WEIGHT_TOTAL = Object.values(ENGINE_WEIGHTS).reduce(
  (totalWeight, engineWeight) => totalWeight + engineWeight,
  0
);

module.exports = {
  ENGINE_WEIGHTS,
  ENGINE_WEIGHT_TOTAL,
  ACTIVE_SIGNAL_THRESHOLD,
  CRITICAL_ENGINE_THRESHOLD,
  CRITICAL_ENGINE_THRESHOLDS,
  RISK_SCORE_OVERRIDES,
  ADAPTIVE_SCORING_REASON,
  WEIGHTED_SCORING_REASON,
};
