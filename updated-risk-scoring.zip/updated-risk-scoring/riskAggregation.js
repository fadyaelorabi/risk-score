const {
  ENGINE_WEIGHTS,
  ACTIVE_SIGNAL_THRESHOLD,
  RISK_SCORE_OVERRIDES,
  ADAPTIVE_SCORING_REASON,
} = require('./engineWeights');
const { clampScore } = require('./scoreNormalization');
const { riskLevelFromScore } = require('./riskLevels');

function normalizedRiskComponents(components = {}) {
  return {
    vulnerability: clampScore(components.vulnerability),
    typosquat: clampScore(components.typosquat),
    maintainer: clampScore(components.maintainer),
    ml: clampScore(components.ml),
  };
}

function aggregateRiskComponents(components) {
  return aggregateRiskDecision(components).totalScore;
}

function activeRiskComponents(normalizedComponents) {
  return Object.fromEntries(
    Object.entries(normalizedComponents).filter(([, score]) => score >= ACTIVE_SIGNAL_THRESHOLD)
  );
}

function emptyEffectiveWeights() {
  return Object.fromEntries(Object.keys(ENGINE_WEIGHTS).map((component) => [component, 0]));
}

function effectiveRiskWeights(activeComponents) {
  const activeNames = Object.keys(activeComponents);
  const activeWeightTotal = activeNames.reduce(
    (totalWeight, component) => totalWeight + ENGINE_WEIGHTS[component],
    0
  );

  if (activeWeightTotal <= 0) return emptyEffectiveWeights();

  return Object.fromEntries(
    Object.keys(ENGINE_WEIGHTS).map((component) => [
      component,
      Object.prototype.hasOwnProperty.call(activeComponents, component)
        ? ENGINE_WEIGHTS[component] / activeWeightTotal
        : 0,
    ])
  );
}

function adaptiveRiskScore(normalizedComponents) {
  const activeComponents = activeRiskComponents(normalizedComponents);
  const effectiveWeights = effectiveRiskWeights(activeComponents);

  const score = Object.entries(activeComponents).reduce(
    (totalScore, [component, componentScore]) =>
      totalScore + componentScore * effectiveWeights[component],
    0
  );

  return {
    score: clampScore(score),
    activeComponents,
    effectiveWeights,
  };
}

function overrideRiskDecision(normalizedComponents) {
  const overrideRule = RISK_SCORE_OVERRIDES.find(
    (rule) => normalizedComponents[rule.component] > rule.threshold
  );
  if (!overrideRule) return null;

  const componentScore = normalizedComponents[overrideRule.component];
  return {
    totalScore: 100,
    calculationMode: 'override',
    triggerReason: `High risk because ${overrideRule.label} exceeded the critical threshold (${componentScore} > ${overrideRule.threshold}).`,
    override: {
      component: overrideRule.component,
      scoreName: overrideRule.scoreName,
      label: overrideRule.label,
      threshold: overrideRule.threshold,
      score: componentScore,
    },
  };
}

function aggregateRiskDecision(components) {
  const normalizedComponents = normalizedRiskComponents(components);
  const overrideDecision = overrideRiskDecision(normalizedComponents);

  if (overrideDecision) {
    return {
      ...overrideDecision,
      components: normalizedComponents,
      activeComponents: activeRiskComponents(normalizedComponents),
      weights: ENGINE_WEIGHTS,
      effectiveWeights: null,
      activationThreshold: ACTIVE_SIGNAL_THRESHOLD,
    };
  }

  const adaptiveDecision = adaptiveRiskScore(normalizedComponents);
  const activeNames = Object.keys(adaptiveDecision.activeComponents);
  const activeText = activeNames.length ? activeNames.join(', ') : 'none';

  return {
    totalScore: adaptiveDecision.score,
    calculationMode: 'adaptive_weighted',
    triggerReason: `${ADAPTIVE_SCORING_REASON} Active components: ${activeText}.`,
    components: normalizedComponents,
    activeComponents: adaptiveDecision.activeComponents,
    // Base weights remain available for configuration and display.
    weights: ENGINE_WEIGHTS,
    // These are the re-normalized weights used in this package calculation.
    effectiveWeights: adaptiveDecision.effectiveWeights,
    activationThreshold: ACTIVE_SIGNAL_THRESHOLD,
  };
}

function rawScanScore(score) {
  if (typeof score === 'number') return score;
  return score?.totalScore ?? score?.score;
}

function normalizedScanScores(scores) {
  return (Array.isArray(scores) ? scores : [])
    .map(rawScanScore)
    // Missing or failed package results are excluded instead of becoming zero.
    .filter((score) => Number.isFinite(Number(score)))
    .map((score) => clampScore(score));
}

function emptyScanRisk() {
  return {
    dependencyCount: 0,
    overallRiskScore: 0,
    overallScore: 100,
    highRiskCount: 0,
    mediumRiskCount: 0,
    lowRiskCount: 0,
  };
}

function averageScore(scoreList) {
  return scoreList.reduce((totalScore, score) => totalScore + score, 0) / scoreList.length;
}

function topMeanScore(scoreList) {
  const sortedScores = [...scoreList].sort((leftScore, rightScore) => rightScore - leftScore);
  const topCount = Math.max(1, Math.ceil(sortedScores.length * 0.1));
  return sortedScores.slice(0, topCount).reduce((totalScore, score) => totalScore + score, 0) / topCount;
}

function riskCounts(scoreList) {
  const highRiskCount = scoreList.filter((score) => riskLevelFromScore(score) === 'high_risk').length;
  const mediumRiskCount = scoreList.filter((score) => riskLevelFromScore(score) === 'suspicious').length;
  const lowRiskCount = scoreList.filter((score) => riskLevelFromScore(score) === 'safe').length;

  return { highRiskCount, mediumRiskCount, lowRiskCount };
}

function exposureScore(scoreList, counts) {
  if (!scoreList.length) return 0;

  return clampScore(
    (counts.highRiskCount / scoreList.length) * 100 +
      (counts.mediumRiskCount / scoreList.length) * 40
  );
}

function scoreScanRisk(scores) {
  const scoreList = normalizedScanScores(scores);
  if (!scoreList.length) return emptyScanRisk();

  const counts = riskCounts(scoreList);
  const topRiskMean = topMeanScore(scoreList);
  const packageRiskMean = averageScore(scoreList);
  const exposure = exposureScore(scoreList, counts);
  const overallRiskScore = clampScore(
    topRiskMean * 0.45 + packageRiskMean * 0.35 + exposure * 0.2
  );

  return {
    dependencyCount: scoreList.length,
    overallRiskScore,
    overallScore: clampScore(100 - overallRiskScore),
    highRiskCount: counts.highRiskCount,
    mediumRiskCount: counts.mediumRiskCount,
    lowRiskCount: counts.lowRiskCount,
    topRiskMean: clampScore(topRiskMean),
    packageRiskMean: clampScore(packageRiskMean),
    exposureScore: exposure,
  };
}

module.exports = {
  normalizedRiskComponents,
  activeRiskComponents,
  effectiveRiskWeights,
  adaptiveRiskScore,
  aggregateRiskDecision,
  aggregateRiskComponents,
  scoreScanRisk,
};
