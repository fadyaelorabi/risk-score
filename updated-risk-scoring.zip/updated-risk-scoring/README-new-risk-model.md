# Updated Risk Scoring Model

The implementation now follows this order:

1. Normalize all four component scores to `0..100`.
2. Apply the hard override when the first prioritized component is strictly greater than `70`.
3. When no override applies, keep only components with a score of at least `20`.
4. Re-normalize the configured weights across those active components.
5. Compute the adaptive weighted score.
6. Return `0` when no component reaches the activation threshold.
7. Clamp and round package, exposure, scan-risk, and health scores to `0..100`.

The response now includes:

- `activeComponents`
- `activationThreshold`
- `effectiveWeights`
- `calculationMode: "adaptive_weighted"` when no override applies

External or missing package score results are excluded from scan aggregation instead of being converted to zero.

## Important behavior

A score of exactly `70` does not trigger the hard override. It can still produce a final package score of `70`, which is classified as `high_risk` by the existing risk-level boundaries.
