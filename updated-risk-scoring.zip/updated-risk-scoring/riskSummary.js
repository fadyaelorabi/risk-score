/**
 * Derive risk metrics from dependency graph nodes (post vulnerability scan).
 *
 * Supports two severity formats:
 *   1. Flat string: `{ severity: 'high' }`
 *   2. Nested object: `{ severity: { level: 'HIGH', score: 7.2, cvss: '...' } }`
 *
 * @param {Array<Record<string, unknown>>} nodes
 */
const { normalizeSeverityString } = require('../../utils/riskUtils');
const { computeRiskFromVulnerabilities, scoreScanRisk } = require('./riskScoringService');

function summarizePackageRiskBuckets(nodes) {
  const list = Array.isArray(nodes) ? nodes : [];
  let safeCount = 0;
  let suspiciousCount = 0;
  let highRiskCount = 0;

  for (const n of list) {
    if (n && n.type === 'root') continue;
    const vulns = Array.isArray(n.vulns) ? n.vulns : [];
    if (vulns.length === 0) {
      if (n.status === 'unknown') suspiciousCount += 1;
      else safeCount += 1;
      continue;
    }

    const risk = computeRiskFromVulnerabilities(vulns);
    if (risk.level === 'high_risk') highRiskCount += 1;
    else if (risk.level === 'suspicious') suspiciousCount += 1;
    else safeCount += 1;
  }

  return { safeCount, suspiciousCount, highRiskCount };
}

/**
 * Count individual vulnerability records by coarse severity.
 * @param {Array<Record<string, unknown>>} nodes
 */
function countVulnerabilitySeverities(nodes) {
  const list = Array.isArray(nodes) ? nodes : [];
  let highRiskCount = 0;
  let mediumRiskCount = 0;
  let lowRiskCount = 0;

  for (const n of list) {
    for (const v of n.vulns || []) {
      const l = normalizeSeverityString(v?.severity);
      if (l === 'HIGH' || l === 'CRITICAL') highRiskCount += 1;
      else if (l === 'MEDIUM') mediumRiskCount += 1;
      else if (l === 'LOW') lowRiskCount += 1;
    }
  }

  return { highRiskCount, mediumRiskCount, lowRiskCount };
}

/**
 * Legacy bucket-only health approximation.
 *
 * Do not use this function as the final scan health score because bucket counts
 * cannot reproduce the top-10%, mean-score, and exposure aggregation model.
 * Use scanRiskFromPackageScores when package scores are available.
 */
function overallScoreFromBuckets(safe, suspicious, high) {
  const total = safe + suspicious + high;
  if (total <= 0) return 100;
  return Math.max(0, Math.min(100, Math.round((100 * safe) / total)));
}

/**
 * Compute the authoritative scan-level risk and health values from package
 * risk scores using the shared aggregation model.
 *
 * @param {Array<number|{score?: number, totalScore?: number}>} packageScores
 */
function scanRiskFromPackageScores(packageScores) {
  return scoreScanRisk(packageScores);
}

/**
 * @param {object} summary
 * @param {{ nodes?: unknown[] }} graph
 */
function dependencyCountFrom(summary, graph) {
  const fromSummary = summary?.nodes?.total;
  if (typeof fromSummary === 'number' && fromSummary >= 0) return fromSummary;
  const nodes = graph?.nodes || [];
  return nodes.filter((n) => n && n.type !== 'root').length || nodes.length;
}

module.exports = {
  normalizeSeverityString,
  summarizePackageRiskBuckets,
  countVulnerabilitySeverities,
  overallScoreFromBuckets,
  scanRiskFromPackageScores,
  dependencyCountFrom,
};
