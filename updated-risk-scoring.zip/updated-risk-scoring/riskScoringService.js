const {
  scoreVulnerabilities,
  scoreAnalysis,
  scoreDependencyRisk,
  scoreScanRisk,
} = require('./riskScoreEngine');

/**
 * Computes risk level and score for a dependency based on vulnerabilities
 * @param {Array} vulnerabilities - Array of vulnerability objects
 * @returns {Object} { level: string, score: number }
 */
function computeRiskFromVulnerabilities(vulnerabilities) {
  const risk = scoreVulnerabilities(vulnerabilities);
  return { level: risk.level, score: risk.score };
}

/**
 * Computes risk metrics for graph nodes
 * @param {Array} nodes - Graph nodes with vulns
 * @returns {Object} Risk summary
 */
function computeNodeRisks(nodes) {
  const result = { safe: 0, suspicious: 0, high_risk: 0 };

  for (const node of nodes) {
    if (node.type === 'root') continue;

    const vulns = node.vulns || [];
    const risk = computeRiskFromVulnerabilities(vulns);

    if (risk.level === 'high_risk') {
      result.high_risk++;
    } else if (risk.level === 'suspicious') {
      result.suspicious++;
    } else {
      result.safe++;
    }

    node.riskLevel = risk.level;
    node.riskScore = risk.score;
  }

  return result;
}

module.exports = {
  computeRiskFromVulnerabilities,
  computeNodeRisks,
  scoreVulnerabilities,
  scoreAnalysis,
  scoreDependencyRisk,
  scoreScanRisk,
};
