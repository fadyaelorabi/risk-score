const { clampScore } = require('./scoreNormalization');

const RISK_LEVEL_THRESHOLDS = Object.freeze({
  suspicious: 20,
  highRisk: 70,
});

function riskLevelFromScore(score) {
  const normalizedScore = clampScore(score);
  if (normalizedScore >= RISK_LEVEL_THRESHOLDS.highRisk) return 'high_risk';
  if (normalizedScore >= RISK_LEVEL_THRESHOLDS.suspicious) return 'suspicious';
  return 'safe';
}

function colorForRiskLevel(riskLevel) {
  if (riskLevel === 'high_risk') return '#FF6B6B';
  if (riskLevel === 'suspicious') return '#FFB300';
  return '#51CF66';
}

function isRiskyScore(score) {
  return riskLevelFromScore(score) !== 'safe';
}

module.exports = {
  RISK_LEVEL_THRESHOLDS,
  riskLevelFromScore,
  colorForRiskLevel,
  isRiskyScore,
};
