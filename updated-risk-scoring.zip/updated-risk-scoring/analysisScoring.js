const { clampScore, normalizeFractionalScore } = require('./scoreNormalization');
const { severityScore } = require('./vulnerabilityScoring');
const { ACTIVE_SIGNAL_THRESHOLD, CRITICAL_ENGINE_THRESHOLD } = require('./engineWeights');

function mlScoreFromAnalysis(analysis) {
  if (typeof analysis?.mlScore === 'number') return normalizeFractionalScore(analysis.mlScore);
  return clampScore(analysis?.anomalyScore);
}

function maintainerScoreFromFindings(findings) {
  if (!Array.isArray(findings) || !findings.length) return null;
  return clampScore(Math.max(...findings.map((finding) => clampScore(finding?.score))));
}

function confirmedBreachInfo(analysis) {
  const breachInfo = analysis?.breachInfo;
  if (!breachInfo) return null;

  if (breachInfo.breached === false || breachInfo.breached === 0) return null;
  if (breachInfo.breached === true || breachInfo.breached === 1) return breachInfo;

  // Some callers store only the selected breach record rather than a wrapper.
  if (
    breachInfo.latest_breach ||
    breachInfo.name ||
    breachInfo.breach_date ||
    breachInfo.BreachDate
  ) {
    return breachInfo;
  }

  return null;
}

function maintainerScoreFromSignals(analysis) {
  const signals = analysis?.maintainerSignals ?? {};
  const signalEntries = Object.values(signals);
  const breachInfo = confirmedBreachInfo(analysis);
  const hasScannerSignalData = signalEntries.length > 0 || analysis?.breachInfo != null;
  if (!hasScannerSignalData) return null;

  const highestSignalScore = signalEntries.reduce((highestScore, signal) => {
    if (Number(signal?.value ?? 0) <= 0) return highestScore;

    const mappedSeverity = severityScore(signal?.severity_level);
    // A positive signal without a recognized severity is treated as moderate
    // evidence, not as a critical event.
    const fallbackScore = mappedSeverity > 0 ? mappedSeverity : 55;
    return Math.max(highestScore, fallbackScore);
  }, 0);

  const breachScore = breachInfo
    ? severityScore(
        analysis?.breachSeverityLevel ??
          breachInfo?.severity_level ??
          breachInfo?.latest_breach?.severity_level
      )
    : 0;

  return clampScore(Math.max(highestSignalScore, breachScore));
}

function maintainerScoreFromAnalysis(analysis) {
  const findingScore = maintainerScoreFromFindings(analysis?.maintainerFindings);
  if (findingScore != null) return findingScore;

  const scannerScore = maintainerScoreFromSignals(analysis);
  if (scannerScore != null) return scannerScore;

  return clampScore(analysis?.signals?.maintainerRisk);
}

function typosquatScoreFromAnalysis(analysis) {
  return Math.max(
    clampScore(analysis?.signals?.typosquattingRisk),
    normalizeFractionalScore(analysis?.typosquatSimilarity)
  );
}

function analysisReasons(components) {
  const reasons = [];

  if (components.ml > CRITICAL_ENGINE_THRESHOLD) {
    reasons.push('ML anomaly score exceeded the critical threshold.');
  } else if (components.ml >= ACTIVE_SIGNAL_THRESHOLD) {
    reasons.push('ML anomaly signal contributed to the package risk score.');
  }

  if (components.maintainer > CRITICAL_ENGINE_THRESHOLD) {
    reasons.push('Maintainer risk score exceeded the critical threshold.');
  } else if (components.maintainer >= ACTIVE_SIGNAL_THRESHOLD) {
    reasons.push('Maintainer risk signal contributed to the package risk score.');
  }

  if (components.typosquat > CRITICAL_ENGINE_THRESHOLD) {
    reasons.push('Typosquatting score exceeded the critical threshold.');
  } else if (components.typosquat >= ACTIVE_SIGNAL_THRESHOLD) {
    reasons.push('Typosquatting signal contributed to the package risk score.');
  }

  return reasons;
}

function scoreAnalysis(analysis) {
  const components = {
    ml: mlScoreFromAnalysis(analysis),
    maintainer: maintainerScoreFromAnalysis(analysis),
    typosquat: typosquatScoreFromAnalysis(analysis),
  };

  return {
    ...components,
    reasons: analysisReasons(components),
  };
}

module.exports = {
  mlScoreFromAnalysis,
  maintainerScoreFromAnalysis,
  typosquatScoreFromAnalysis,
  scoreAnalysis,
};
