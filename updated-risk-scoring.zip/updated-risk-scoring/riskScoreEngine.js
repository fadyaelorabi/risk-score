const {
  clampScore,
  normalizeFractionalScore,
  combineIndependentScores,
} = require('./scoreNormalization');
const {
  RISK_LEVEL_THRESHOLDS,
  riskLevelFromScore,
  colorForRiskLevel,
  isRiskyScore,
} = require('./riskLevels');
const {
  ENGINE_WEIGHTS,
  ENGINE_WEIGHT_TOTAL,
  ACTIVE_SIGNAL_THRESHOLD,
} = require('./engineWeights');
const {
  severityScore,
  cvssToRiskScore,
  vulnerabilityBaseScore,
  scoreVulnerabilities,
} = require('./vulnerabilityScoring');
const {
  scoreAnalysis,
  mlScoreFromAnalysis,
  maintainerScoreFromAnalysis,
  typosquatScoreFromAnalysis,
} = require('./analysisScoring');
const {
  normalizedRiskComponents,
  activeRiskComponents,
  effectiveRiskWeights,
  adaptiveRiskScore,
  aggregateRiskDecision,
  aggregateRiskComponents,
  scoreScanRisk,
} = require('./riskAggregation');

function packageNameForRisk(dependency, graphNode) {
  return dependency?.name || graphNode?.name || graphNode?.label || graphNode?.id || 'package';
}

function riskIdForPackage(dependency, graphNode, packageName) {
  if (graphNode?.id) return graphNode.id;
  if (dependency?._id) return String(dependency._id);
  return `${packageName}-risk`;
}

function scoreDependencyRisk({ dependency, vulnerabilities, analysis, graphNode } = {}) {
  const vulnerabilityRisk = scoreVulnerabilities(vulnerabilities);
  const analysisRisk = scoreAnalysis(analysis);
  const components = normalizedRiskComponents({
    vulnerability: vulnerabilityRisk.score,
    typosquat: analysisRisk.typosquat,
    maintainer: analysisRisk.maintainer,
    ml: analysisRisk.ml,
  });
  const riskDecision = aggregateRiskDecision(components);
  const totalScore = riskDecision.totalScore;
  const finalRiskLevel = riskLevelFromScore(totalScore);
  const packageName = packageNameForRisk(dependency, graphNode);

  return {
    riskId: riskIdForPackage(dependency, graphNode, packageName),
    packageName,
    totalScore,
    score: totalScore,
    overallRisk: totalScore,
    overallRiskScore: totalScore,
    finalRiskLevel,
    level: finalRiskLevel,
    components,
    riskComponents: components,
    activeComponents: riskDecision.activeComponents,
    riskActiveComponents: riskDecision.activeComponents,
    activationThreshold: riskDecision.activationThreshold,
    riskActivationThreshold: riskDecision.activationThreshold,
    // Configured base weights.
    weights: riskDecision.weights,
    riskWeights: riskDecision.weights,
    // Re-normalized weights actually used for adaptive scoring.
    effectiveWeights: riskDecision.effectiveWeights,
    riskEffectiveWeights: riskDecision.effectiveWeights,
    calculationMode: riskDecision.calculationMode,
    riskCalculationMode: riskDecision.calculationMode,
    triggerReason: riskDecision.triggerReason,
    riskTriggerReason: riskDecision.triggerReason,
    override: riskDecision.override,
    riskOverride: riskDecision.override,
    reasons: [...vulnerabilityRisk.reasons, ...analysisRisk.reasons],
    analysisId: analysis?._id ? String(analysis._id) : undefined,
  };
}

function graphRiskFields(risk) {
  return {
    riskScore: risk.totalScore,
    riskLevel: risk.finalRiskLevel,
    riskComponents: risk.components,
    riskActiveComponents: risk.activeComponents,
    riskActivationThreshold: risk.activationThreshold,
    riskReasons: risk.reasons,
    riskTriggerReason: risk.triggerReason,
    riskCalculationMode: risk.calculationMode,
    riskWeights: risk.weights,
    riskEffectiveWeights: risk.effectiveWeights,
    riskOverride: risk.override,
  };
}

module.exports = {
  ENGINE_WEIGHTS,
  ENGINE_WEIGHT_TOTAL,
  ACTIVE_SIGNAL_THRESHOLD,
  RISK_LEVEL_THRESHOLDS,
  clampScore,
  normalizeFractionalScore,
  combineIndependentScores,
  riskLevelFromScore,
  colorForRiskLevel,
  isRiskyScore,
  severityScore,
  cvssToRiskScore,
  vulnerabilityBaseScore,
  normalizedRiskComponents,
  activeRiskComponents,
  effectiveRiskWeights,
  adaptiveRiskScore,
  aggregateRiskDecision,
  aggregateRiskComponents,
  mlScoreFromAnalysis,
  maintainerScoreFromAnalysis,
  typosquatScoreFromAnalysis,
  scoreVulnerabilities,
  scoreAnalysis,
  scoreDependencyRisk,
  graphRiskFields,
  scoreScanRisk,
};
