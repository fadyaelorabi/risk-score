const assert = require('node:assert/strict');
const {
  aggregateRiskDecision,
  scoreScanRisk,
} = require('./riskAggregation');

function check(name, fn) {
  try {
    fn();
    console.log(`PASS: ${name}`);
  } catch (error) {
    console.error(`FAIL: ${name}`);
    throw error;
  }
}

check('ML 40 and maintainer 40 normalize to package risk 40', () => {
  const result = aggregateRiskDecision({ vulnerability: 0, ml: 40, maintainer: 40, typosquat: 0 });
  assert.equal(result.totalScore, 40);
  assert.equal(result.calculationMode, 'adaptive_weighted');
  assert.deepEqual(result.activeComponents, { maintainer: 40, ml: 40 });
  assert.equal(result.effectiveWeights.ml, 0.5);
  assert.equal(result.effectiveWeights.maintainer, 0.5);
});

check('signals below 20 do not contribute', () => {
  const result = aggregateRiskDecision({ vulnerability: 0, ml: 15, maintainer: 19, typosquat: 0 });
  assert.equal(result.totalScore, 0);
  assert.deepEqual(result.activeComponents, {});
});

check('single active component retains its score', () => {
  const result = aggregateRiskDecision({ vulnerability: 60, ml: 0, maintainer: 0, typosquat: 0 });
  assert.equal(result.totalScore, 60);
  assert.equal(result.effectiveWeights.vulnerability, 1);
});

check('score above 70 triggers hard override', () => {
  const result = aggregateRiskDecision({ vulnerability: 0, ml: 0, maintainer: 0, typosquat: 71 });
  assert.equal(result.totalScore, 100);
  assert.equal(result.calculationMode, 'override');
  assert.equal(result.override.component, 'typosquat');
});

check('score equal to 70 does not trigger hard override', () => {
  const result = aggregateRiskDecision({ vulnerability: 0, ml: 70, maintainer: 0, typosquat: 0 });
  assert.equal(result.totalScore, 70);
  assert.equal(result.calculationMode, 'adaptive_weighted');
});

check('missing scan entries are excluded rather than converted to zero', () => {
  const result = scoreScanRisk([100, undefined, null, { totalScore: 40 }]);
  assert.equal(result.dependencyCount, 2);
});

check('exposure score reflects high-risk and suspicious proportions', () => {
  const result = scoreScanRisk([100, 100, 40, 40]);
  assert.equal(result.exposureScore, 70);
});

check('exposure score reaches 100 when all packages are high risk', () => {
  const result = scoreScanRisk([100, 80, 70]);
  assert.equal(result.exposureScore, 100);
});

console.log('All risk-model tests passed.');
