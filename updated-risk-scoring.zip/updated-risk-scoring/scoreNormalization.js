const MIN_RISK_SCORE = 0;
const MAX_RISK_SCORE = 100;

function clampScore(value) {
  const numericScore = Number(value);
  if (!Number.isFinite(numericScore)) return MIN_RISK_SCORE;
  return Math.max(MIN_RISK_SCORE, Math.min(MAX_RISK_SCORE, Math.round(numericScore)));
}

function normalizeFractionalScore(value) {
  const numericScore = Number(value);
  if (!Number.isFinite(numericScore)) return MIN_RISK_SCORE;
  return numericScore <= 1 ? clampScore(numericScore * MAX_RISK_SCORE) : clampScore(numericScore);
}

function combineIndependentScores(scores) {
  const survival = scores
    .map((score) => clampScore(score) / MAX_RISK_SCORE)
    .reduce((remainingProbability, riskProbability) => remainingProbability * (1 - riskProbability), 1);

  return clampScore((1 - survival) * MAX_RISK_SCORE);
}

module.exports = {
  MIN_RISK_SCORE,
  MAX_RISK_SCORE,
  clampScore,
  normalizeFractionalScore,
  combineIndependentScores,
};
